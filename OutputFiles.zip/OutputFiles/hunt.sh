#!/bin/bash

PDBFILES=`ls */*minimised.pdb`

for file in $PDBFILES;
do
count=`cat $file | wc -l`
if [ "$count" == "45" ]; then
echo $file
fi
done

